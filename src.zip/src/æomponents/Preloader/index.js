import Preloader from './Preloader';
export default Preloader;